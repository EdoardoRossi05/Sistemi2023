﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dikjstra
{
    public class Arco
    {
        private int peso;
        private Nodo destinazione;

        public Arco(Nodo destinazione, int peso)
        {
            this.destinazione = destinazione;
            this.peso = peso;
        }

        public Nodo Destinazione
        {
            get { return destinazione; }
        }

        public int Peso
        {
            get { return peso; }
        }
    }
}
