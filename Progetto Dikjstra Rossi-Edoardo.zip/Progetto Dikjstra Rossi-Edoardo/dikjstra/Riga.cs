﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dikjstra
{
    public class Riga
    {
        private string da;
        private string a;
        private int costo;
        private bool visitato;
        private string precedente;

        public string Da => da;
        public string A => a;
        public int Costo
        {
            get => costo;
            set => costo = value;
        }
        public bool Visitato
        {
            get => visitato;
            set => visitato = value;
        }
        public string Precedente
        {
            get => precedente;
            set => precedente = value;
        }

        public Riga(string da, string a, int costo)
        {
            this.da = da;
            this.a = a;
            this.costo = costo;
            this.visitato = false;
            this.precedente = null;
        }
    }

}
