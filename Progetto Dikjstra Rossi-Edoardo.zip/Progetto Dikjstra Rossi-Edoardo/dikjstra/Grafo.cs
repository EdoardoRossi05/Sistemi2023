﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dikjstra
{
    public class Grafo
    {
        private List<Nodo> nodi;
        public Grafo(Nodo n)
        {
            nodi = new List<Nodo>();
            nodi.Add(n);
            int index = 0;

            while (index < nodi.Count)
            {
                Nodo nodoCorrente = nodi[index];

                foreach (Arco a in nodoCorrente.Archi)
                {
                    Nodo nodoDestinazione = a.Destinazione;
                    bool nodoGiaPresente = false;

                    foreach (Nodo nodo in nodi)
                    {
                        if (nodo.Nome.Equals(nodoDestinazione.Nome))
                        {
                            nodoGiaPresente = true;
                            break;
                        }
                    }

                    if (!nodoGiaPresente)
                    {
                        nodi.Add(nodoDestinazione);
                    }
                }

                index++;
            }
        }

        public List<Riga> CamminoMinimo(Nodo partenza, Nodo arrivo)
        {
            List<Riga> finale = new List<Riga>();

            foreach (Nodo nodo in nodi)
            {
                finale.Add(new Riga(partenza.Nome, nodo.Nome, int.MaxValue));
            }

            finale[nodi.IndexOf(partenza)].Costo = 0;

            while (true)
            {
                Riga minimo = finale.Find(r => !r.Visitato && r.Costo != int.MaxValue);

                if (minimo == null)
                {
                    break;
                }

                minimo.Visitato = true;

                if (minimo.A == arrivo.Nome)
                {
                    break;
                }

                foreach (Arco a in nodi.Find(x => x.Nome.Equals(minimo.A)).Archi)
                {
                    Riga riga = finale.Find(x => x.A.Equals(a.Destinazione.Nome));
                    int nuovoCosto = minimo.Costo + a.Peso;
                    if (nuovoCosto < riga.Costo)
                    {
                        riga.Costo = nuovoCosto;
                        riga.Precedente = minimo.A;
                    }
                }
            }

            return finale;
        }
    }
}
    

