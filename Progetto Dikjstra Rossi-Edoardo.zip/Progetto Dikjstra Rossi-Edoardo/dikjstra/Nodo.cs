﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dikjstra
{
    public class Nodo
    {
        private static int index = 0;
        private string nome;
        private List<Arco> archi;

        public Nodo()
        {
            archi = new List<Arco>();
            index++;
            nome = index.ToString();
        }

        public Nodo(string nome)
        {
            archi = new List<Arco>();
            this.nome = nome;
        }

        public string Nome
        {
            get { return nome; }
        }

        public List<Arco> Archi
        {
            get { return archi; }
        }

        public List<Riga> CamminoMinimo(Nodo partenza, Nodo arrivo)
        {
            Grafo g = new Grafo(this);
            return g.CamminoMinimo(partenza, arrivo);
        }
    }

}
