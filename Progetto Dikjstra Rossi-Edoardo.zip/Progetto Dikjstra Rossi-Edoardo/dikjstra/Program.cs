﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace dikjstra
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Ottenere il numero di nodi e i pesi degli archi dall'utente
            Console.Write("Inserisci il numero di nodi: ");
            int numeroNodi = int.Parse(Console.ReadLine());

            List<Nodo> nodi = new List<Nodo>();

            // Creazione dei nodi
            for (int i = 1; i <= numeroNodi; i++)
            {
                nodi.Add(new Nodo(i.ToString()));
            }

            Console.WriteLine();

            // Creazione degli archi
            for (int i = 0; i < numeroNodi; i++)
            {
                Nodo nodoCorrente = nodi[i];

                for (int j = i + 1; j < numeroNodi; j++)
                {
                    Console.Write($"Inserisci il peso dell'arco tra {nodoCorrente.Nome} e {nodi[j].Nome}: ");
                    int peso = int.Parse(Console.ReadLine());

                    nodoCorrente.Archi.Add(new Arco(nodi[j], peso));
                    nodi[j].Archi.Add(new Arco(nodoCorrente, peso));

                    Console.WriteLine();
                }
            }

            // Creazione del grafo
            Nodo partenza, arrivo;

            // Selezione del nodo di partenza e di arrivo
            while (true)
            {
                Console.Write("Inserisci il numero del nodo di partenza: ");
                int numeroPartenza = int.Parse(Console.ReadLine());

                Console.Write("Inserisci il numero del nodo di arrivo: ");
                int numeroArrivo = int.Parse(Console.ReadLine());

                partenza = nodi.Find(n => n.Nome.Equals(numeroPartenza.ToString()));
                arrivo = nodi.Find(n => n.Nome.Equals(numeroArrivo.ToString()));

                if (partenza != null && arrivo != null)
                {
                    break;
                }

                Console.WriteLine("Nodi di partenza o arrivo non validi. Riprova.");
                Console.WriteLine();
            }

            Grafo grafo = new Grafo(partenza);

            // Calcolo del cammino minimo
            List<Riga> camminoMinimo = grafo.CamminoMinimo(partenza, arrivo);

            // Stampa del cammino minimo
            Console.WriteLine($"Cammino minimo tra {partenza.Nome} e {arrivo.Nome}:");

            foreach (Riga riga in camminoMinimo)
            {
                Console.WriteLine($"{riga.Da} verso {riga.A} = {riga.Costo}");
            }

            Console.ReadLine();
        }
       






    }
}